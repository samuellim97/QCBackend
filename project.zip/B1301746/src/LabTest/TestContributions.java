/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LabTest;
// add the correct package header

import java.time.LocalDate;

/**
 * TestContributions.java to test the Contribution Inheritance
 * Hierarchy you have written in Lab Test 1
 * (15 marks)
 * REPLACE WITH YOUR STUDENTID
 * @author ngsm
 */
public class TestContributions {
    
    public static void main(String[] args)
    {
        // Initializing test values for the instance variables
        LocalDate testDate = LocalDate.now();
        MaterialType testMaterial = MaterialType.CLOTHING;
        String description = "T-shirts";
        double valuePerUnit = 3.50;
        int numUnits = 5;
        double donationAmount = 20;
        
        // 1. Which of the two lines to declare a Contribution
        // is correct? Why? 
        // Comment out the wrong line and explain your answer in a comment.
        // (2 marks)
        //Contribution cont = new Contribution(testDate) ;    
        Contribution cont = null;          
        /**
         * 1- Contribution is an abstract class. It cannot 
         * be instantiated.
         */
        
        
        // 2. create a Material object 
        // using the correct test values from lines 11 - 19 above
        // (2 marks)
        Material mat = new Material(testDate, testMaterial, 
                description, valuePerUnit, numUnits);      // fill in the rest
        
        // 3. create a Monetary  object 
        // using the correct test values from lines 11 - 19 above
        // (2 marks)
        Monetary mon =  new Monetary(testDate, donationAmount);         // fill in the rest
        
        // For each of the following lines 40 - 44, state whether it will have:
        // a) a compile error
        // b) a possible runtime error
        // c) no error?
        // explain why, in your comments.
        // then comment out the errors
        // 5 marks
        //mat = mon;   // both objects are in the same level of inheritence, 
                     //thus incompatible      
        //mat = cont;   //Cannot typecast, objects that are same level of
                      //inheritance.
        cont = mon;   // Superclass objects can hold any subclass object.
        mon = (Monetary) cont;    // Valid because, cont holds a reference to a 
                                  // valid Monetary object.
        //mat = (Material) cont;    // This will create a runtime error, since.
                                    // cont actually stores a Monetary object,
                                    // which cannot be typecasted.
        
        // Which method is invoked in each of the following:
        // a) the one in Contribution
        // b) the one in Material
        // c) the one in Monetary
        // give your answer and explain why in the comments
        // 4 marks
        System.out.println(cont.toString()); //c. if the invoked method is defined 
                                            //in the Object, Java will call that method.
                                            //The Object is a Material Object in the memory.
        System.out.println(mat.toString());  //b.
        System.out.println(cont.getValue()); //c. Because the getValue() method in
                                             //Contrution class is just an abstract method.
        System.out.println(mon.getValue());  //c
        
    }
}

