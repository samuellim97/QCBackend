/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LabTest;

import java.time.LocalDate;

/**
 * A Material donation to the Organization.
 * 
 * @author shath
 */
public class Material extends Contribution {
    private MaterialType category;
    private String itemDescription;
    private double valuePerUnit;
    private int numUnitsContributed;

    /**
     * The constructor  must receive parameters date,
     * category , description ,
     *  valuePerUnit , numUnitsContributed with the 
     * correct data types
     * 
     * @param date
     * @param category
     * @param itemDescription
     * @param valuePerUnit
     * @param numUnitsContributed 
     */
    public Material(
            LocalDate date,
            MaterialType category, 
            String itemDescription, 
            double valuePerUnit,
            int numUnitsContributed
            ) {
        
        super(date);
        
        //do validation
        if(itemDescription == null || itemDescription.length()==0)
            itemDescription = "unknown";
        if(valuePerUnit < 0) valuePerUnit = 0;
        if (numUnitsContributed < 0) numUnitsContributed = 0;
        
        //set data
        setCategory(category);
        setItemDescription(itemDescription);
        setValuePerUnit(valuePerUnit);
        setNumUnitsContributed(numUnitsContributed);  
        
    }

    @Override
    public double getValue() {
        return valuePerUnit * numUnitsContributed;
    }

    /**
     * Prints the string formatted
     * @return 
     */
    @Override
    public String toString() {        
        StringBuilder sb = 
                new StringBuilder("Material\n"+super.toString());
        sb.append(
                String.format("\ncategory: %s\n description: %s\n value: %f\n", 
                            getCategory().getString(),
                            getItemDescription(),
                            getValue()
                        )        
        );        
        return sb.toString();        
    }

    
    
            
    // -------Access Modifiers below -----------------
    
    
    public MaterialType getCategory() {
        return category;
    }

    public void setCategory(MaterialType category) {
        this.category = category;
    }

    public String getItemDescription() {
        return itemDescription;
    }

    public void setItemDescription(String itemDescription) {
        this.itemDescription = itemDescription;
    }

    public double getValuePerUnit() {
        return valuePerUnit;
    }

    public void setValuePerUnit(double valuePerUnit) {
        this.valuePerUnit = valuePerUnit;
    }

    public int getNumUnitsContributed() {
        return numUnitsContributed;
    }

    public void setNumUnitsContributed(int numUnitsContributed) {
        this.numUnitsContributed = numUnitsContributed;
    }
    
    
    
    
}
