/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LabTest;

import com.sun.org.apache.xalan.internal.xsltc.compiler.util.StringStack;
import java.time.*;

/**
 * Contribution superclass
 * 
 * 
 * @author shath
 */
public abstract class Contribution {
    static private int nextNo = 1000;
    private int contributionNo;
    private LocalDate date;

    /**
     * This method will generate a unique
     * contributionNo for this object
     * using the nextNo static variable.
     */
    public void setContributionNo() {
        setContributionNo(nextNo++);
    }

    /**
     * Initialize a Contribution object.
     * Sets the date, if the date has not passed yet.
     * @param date 
     */
    public Contribution(LocalDate date) {
        setContributionNo();
        if(date.compareTo(LocalDate.now()) <= 0){                        
            setDate(date);
        }else{
            throw new IllegalArgumentException("Invalid date!");
        }
    }

    /**
     * Format and print the object.
     * @return 
     */
    @Override
    public String toString() {
        return String.format(
                    "Contribution %s made on %s", 
                    getContributionNo(),
                    getDate().toString()
                );
    }
    
    /**
     * The value contributed.
     * @return 
     */
    abstract public double getValue();

    
    //----- All the getters and setters            

    public int getContributionNo() {
        return contributionNo;
    }

    /**
     * Setter for the contribution number.
     * We do not want external classes to modify the 
     * contribution number, so this method is protected.
     * @param contributionNo 
     */
    protected void setContributionNo(int contributionNo) {
        this.contributionNo = contributionNo;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }
    
    
    
    
}
