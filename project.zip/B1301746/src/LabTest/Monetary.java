/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LabTest;

import java.time.LocalDate;

/**
 * A Monetory donation
 * @author shath
 */
public class Monetary extends Contribution{
    
    private double donationAmount;

    public Monetary(LocalDate date, double donationAmount) {
        super(date);
        if(donationAmount > 0)
            setDonationAmount(donationAmount);
        
    }

    /**
     * Returns the amount donated
     * @return 
     */
    @Override
    public double getValue() {
        return donationAmount;
    }

    @Override
    public String toString() {
        return 
                super.toString() +
                "\n" +
                "Amount contributed: "+getDonationAmount();
    }
    
    
    
    
    
    public double getDonationAmount() {
        return donationAmount;
    }

    public void setDonationAmount(double donationAmount) {
        this.donationAmount = donationAmount;
    }
    
    
}
