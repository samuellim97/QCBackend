/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LabTest;

/**
 *
 * @author shath
 */
public enum MaterialType {
    SCHOOLSUPPLIES("SCHOOLSUPPLIES"),
    FOOD("FOOD"),
    CLOTHING("CLOTHING");

    private final String str;

    private MaterialType(String string) {
        this.str = string;
    }
    
    

    /**
     * Get the value of string
     *
     * @return the value of string
     */
    public String getString() {
        return str;
    }

    @Override
    public String toString() {
        return getString();
    }
    
    

}


